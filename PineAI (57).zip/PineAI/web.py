"""
PineAI - búsqueda en internet.
Usa ddgs (metabúsqueda: Google, Bing, Brave, DuckDuckGo, Wikipedia...) y lee las mejores páginas.
"""
import re
from concurrent.futures import ThreadPoolExecutor

import requests

NUM_RESULTADOS = 6      # resultados que se piden al buscador
PAGINAS_A_LEER = 3      # páginas que se abren y se leen enteras
MAX_CHARS_PAGINA = 2500 # texto que se aprovecha de cada página
TIMEOUT = 7

CABECERAS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/126.0 Safari/537.36",
    "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
}


def problema():
    """None si se puede buscar; si no, el motivo exacto (qué librería falta y por qué)."""
    try:
        import ddgs  # noqa: F401
        import bs4   # noqa: F401
        return None
    except Exception as e:
        return f"{type(e).__name__}: {e}"


def disponible():
    return problema() is None


def _leer_pagina(url):
    """Devuelve el texto principal de una página, o '' si no se puede."""
    try:
        from bs4 import BeautifulSoup
        r = requests.get(url, headers=CABECERAS, timeout=TIMEOUT)
        if r.status_code != 200 or "html" not in r.headers.get("Content-Type", ""):
            return ""
        # bytes crudos: BeautifulSoup respeta el <meta charset> de la página o lo detecta.
        # (r.text supone Latin-1 si la cabecera HTTP no dice nada, y rompe eñes y tildes)
        cabecera = r.headers.get("Content-Type", "").lower()
        sopa = BeautifulSoup(r.content, "html.parser", from_encoding=r.encoding if "charset" in cabecera else None)
        for etiqueta in sopa(["script", "style", "noscript", "nav", "header", "footer",
                              "aside", "form", "svg", "iframe", "button"]):
            etiqueta.decompose()
        cuerpo = sopa.find("article") or sopa.find("main") or sopa.body or sopa
        texto = cuerpo.get_text(" ", strip=True)
        return re.sub(r"\s+", " ", texto)[:MAX_CHARS_PAGINA]
    except Exception:
        return ""


def buscar(consulta):
    """
    Busca en internet y devuelve una lista de fuentes:
    [{"titulo", "url", "texto"}], donde texto es el contenido leído (o el resumen del buscador).
    """
    from ddgs import DDGS
    resultados = DDGS().text(consulta, max_results=NUM_RESULTADOS, backend="auto")
    vistos, fuentes = set(), []
    for r in resultados:
        url = r.get("href", "")
        dominio = re.sub(r"^https?://(www\.)?", "", url).split("/")[0]
        if not url or url in vistos:
            continue
        vistos.add(url)
        fuentes.append({"titulo": r.get("title", dominio), "url": url,
                        "dominio": dominio, "texto": r.get("body", "")})

    # Leer a la vez las primeras páginas
    a_leer = fuentes[:PAGINAS_A_LEER]
    with ThreadPoolExecutor(max_workers=PAGINAS_A_LEER) as ex:
        textos = list(ex.map(lambda f: _leer_pagina(f["url"]), a_leer))
    for f, t in zip(a_leer, textos):
        if len(t) > len(f["texto"]):
            f["texto"] = t
    return fuentes


def como_contexto(fuentes):
    """Texto para el modelo, con las fuentes numeradas para que las cite."""
    bloques = [f"[{i}] {f['titulo']} ({f['url']})\n{f['texto']}" for i, f in enumerate(fuentes, 1)]
    return ("Resultados de internet. Úsalos para responder, cita cada dato con su número entre "
            "corchetes, por ejemplo [1], y si no bastan dilo:\n\n" + "\n\n".join(bloques))
