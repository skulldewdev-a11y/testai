$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "=== Instalando PineAI ===" -ForegroundColor Cyan

# 1. Ollama
if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
    Write-Host "Instalando Ollama con winget..."
    winget install -e --id Ollama.Ollama --accept-source-agreements --accept-package-agreements
    $env:Path = [Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [Environment]::GetEnvironmentVariable("Path","User")
    $local = Join-Path $env:LOCALAPPDATA "Programs\Ollama"
    if (Test-Path $local) { $env:Path += ";$local" }
}

# 2. Arrancar el servidor si no está corriendo
try { Invoke-RestMethod http://localhost:11434/api/tags -TimeoutSec 3 | Out-Null }
catch {
    Write-Host "Arrancando Ollama..."
    Start-Process ollama -ArgumentList "serve" -WindowStyle Hidden
    Start-Sleep -Seconds 5
}

# 3. Modelos
Write-Host "Descargando modelo de 7B (~4.7 GB)..." -ForegroundColor Cyan
ollama pull qwen2.5-coder:7b
Write-Host "Descargando modelo de embeddings (~270 MB)..." -ForegroundColor Cyan
ollama pull nomic-embed-text
ollama create pineai -f Modelfile

$r = Read-Host "Descargar tambien el modelo de 14B (~9 GB, mas lento pero mas listo)? (s/n)"
if ($r -eq "s") {
    ollama pull qwen2.5-coder:14b
    (Get-Content Modelfile) -replace '^FROM .*', 'FROM qwen2.5-coder:14b' | Set-Content Modelfile.14b
    ollama create pineai-14b -f Modelfile.14b
    Remove-Item Modelfile.14b
}

# 4. Python
if (Get-Command py -ErrorAction SilentlyContinue) { $py = "py" }
elseif (Get-Command python -ErrorAction SilentlyContinue) { $py = "python" }
else {
    Write-Host "No encuentro Python. Instalalo desde python.org (marca 'Add to PATH') y vuelve a ejecutar esto." -ForegroundColor Yellow
    exit 1
}
& $py -m pip install -r requirements.txt

# 5. Voz local (Piper) para la voz con efectos
Write-Host "Instalando la voz local (Piper)..." -ForegroundColor Cyan
& $py -m pip install piper-tts
if ($LASTEXITCODE -ne 0) { Write-Host "No se pudo instalar Piper; PineAI usara la voz de Windows." -ForegroundColor Yellow }
New-Item -ItemType Directory -Force -Path voces | Out-Null
$base = "https://huggingface.co/rhasspy/piper-voices/resolve/main/es/es_ES/davefx/medium/es_ES-davefx-medium"
foreach ($ext in @(".onnx", ".onnx.json")) {
    $destino = "voces\es_ES-davefx-medium$ext"
    if (-not (Test-Path $destino)) {
        Write-Host "Descargando es_ES-davefx-medium$ext..."
        try { Invoke-WebRequest -UseBasicParsing -Uri "$base$ext" -OutFile $destino }
        catch { Write-Host "No se pudo descargar la voz: $_" -ForegroundColor Yellow; Remove-Item $destino -ErrorAction SilentlyContinue }
    }
}

New-Item -ItemType Directory -Force -Path docs | Out-Null
Write-Host "`nListo. Mete tus documentos en la carpeta docs\ y ejecuta iniciar.bat" -ForegroundColor Green
