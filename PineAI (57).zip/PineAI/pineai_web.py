#!/usr/bin/env python3
"""
PineAI Web - interfaz de chat con voz y avatar para PineAI.
Arranca un servidor local en http://localhost:8777 y abre el navegador.
Reutiliza el motor de pineai.py (Ollama + documentos + OBD2).
"""
import json
import os
import threading
import webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

import pineai as core
import web
import claude
import musica
import pc

PUERTO = int(os.environ.get("PINEAI_PUERTO", "8777"))
HTML = os.path.join(core.BASE, "interfaz.html")

estado = {"vec": None, "meta": []}
bloqueo = threading.Lock()

# ---------- Registro de chats (un JSON por conversación en la carpeta chats/) ----------
import re
import time
CHATS_DIR = os.path.join(core.BASE, "chats")
ID_VALIDO = re.compile(r"^[a-z0-9]{6,24}$")   # solo letras y números: nada de rutas raras
bloqueo_chats = threading.Lock()


def ruta_chat(cid):
    if not ID_VALIDO.match(cid or ""):
        return None
    return os.path.join(CHATS_DIR, cid + ".json")


def leer_chat(cid):
    ruta = ruta_chat(cid)
    if not ruta or not os.path.isfile(ruta):
        return None
    with open(ruta, encoding="utf-8") as f:
        return json.load(f)


# ---------- Visor: archivos de la carpeta docs (solo esa carpeta) ----------
import mimetypes
import urllib.parse
TIPOS_TEXTO = {".txt", ".md", ".py", ".js", ".ts", ".c", ".cpp", ".h", ".hpp", ".ino", ".lua", ".json", ".csv",
               ".ini", ".cfg", ".yaml", ".yml", ".xml", ".ps1", ".bat", ".sh", ".dbc", ".log", ".html", ".htm",
               ".css", ".svg", ".sql", ".java", ".cs", ".rs", ".go", ".toml"}


def ruta_en_docs(rel):
    """Ruta absoluta del archivo si está DENTRO de docs/ (resolviendo .. y accesos directos); si no, None."""
    base = os.path.realpath(core.DOCS_DIR)
    ruta = os.path.realpath(os.path.join(base, rel or ""))
    if os.path.commonpath([base, ruta]) != base or not os.path.isfile(ruta):
        return None
    return ruta


def listar_archivos():
    os.makedirs(core.DOCS_DIR, exist_ok=True)
    archivos = []
    for raiz, _, nombres in os.walk(core.DOCS_DIR):
        for n in nombres:
            ruta = os.path.join(raiz, n)
            rel = os.path.relpath(ruta, core.DOCS_DIR).replace(os.sep, "/")
            if ruta_en_docs(rel):          # fuera los accesos directos que apuntan fuera de docs
                archivos.append({"ruta": rel, "tam": os.path.getsize(ruta)})
    return sorted(archivos, key=lambda a: a["ruta"].lower())


# ---------- Servidor de vistas: las páginas se ven desde OTRO puerto ----------
# Para el navegador, otro puerto es otra web: la página puede guardar datos, cargar sus archivos
# y conectarse al bridge, pero no puede tocar PineAI.
PUERTO_VISTAS = PUERTO + 1
# Modo red: si PINEAI_RED=1, escucha en toda la wifi (otros PCs pueden entrar). Por defecto, solo este PC.
EN_RED = os.environ.get("PINEAI_RED") == "1"
HOST = "0.0.0.0" if EN_RED else "127.0.0.1"
VISTAS = {}                     # páginas generadas por la IA: id -> html (en memoria)
bloqueo_vistas = threading.Lock()


class ManejadorVistas(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        ruta = urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        datos, tipo = None, "text/html; charset=utf-8"
        if ruta.startswith("/vista/"):
            with bloqueo_vistas:
                html = VISTAS.get(ruta[len("/vista/"):])
            datos = html.encode("utf-8") if html is not None else None
        elif ruta.startswith("/docs/"):
            real = ruta_en_docs(ruta[len("/docs/"):])
            if real:
                with open(real, "rb") as f:
                    datos = f.read()
                ext = os.path.splitext(real)[1].lower()
                tipo = ("text/html; charset=utf-8" if ext in (".html", ".htm") else
                        mimetypes.guess_type(real)[0] or "application/octet-stream")
                if tipo.startswith("text/") and "charset" not in tipo:
                    tipo += "; charset=utf-8"
        if datos is None:
            self.send_response(404); self.end_headers()
            return
        self.send_response(200)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(datos)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(datos)


def listar_chats():
    os.makedirs(CHATS_DIR, exist_ok=True)
    chats = []
    for nombre in os.listdir(CHATS_DIR):
        if not nombre.endswith(".json"):
            continue
        try:
            with open(os.path.join(CHATS_DIR, nombre), encoding="utf-8") as f:
                c = json.load(f)
            chats.append({"id": c["id"], "titulo": c.get("titulo", "Chat"),
                          "actualizado": c.get("actualizado", 0), "mensajes": len(c.get("mensajes", []))})
        except Exception:
            continue   # un archivo roto no tumba la lista
    return sorted(chats, key=lambda c: c["actualizado"], reverse=True)


def guardar_chat(cid, datos):
    ruta = ruta_chat(cid)
    if not ruta:
        raise ValueError("id de chat no válido")
    with bloqueo_chats:
        os.makedirs(CHATS_DIR, exist_ok=True)
        actual = leer_chat(cid) or {"id": cid, "titulo": "Chat nuevo", "creado": time.time(), "mensajes": []}
        if isinstance(datos.get("titulo"), str) and datos["titulo"].strip():
            actual["titulo"] = datos["titulo"].strip()[:80]
        if isinstance(datos.get("mensajes"), list):
            actual["mensajes"] = datos["mensajes"]
            actual["actualizado"] = time.time()
        actual.setdefault("actualizado", time.time())
        temporal = ruta + ".tmp"          # se escribe aparte y se cambia de golpe: nunca queda a medias
        with open(temporal, "w", encoding="utf-8") as f:
            json.dump(actual, f, ensure_ascii=False)
        os.replace(temporal, ruta)
    return actual

# ---------- Voz local (Piper) ----------
VOCES_DIR = os.path.join(core.BASE, "voces")
piper = {"voz": None, "nombre": None, "cfg": None, "lock": threading.Lock()}


def cargar_piper():
    if not os.path.isdir(VOCES_DIR):
        return
    modelos = sorted(f for f in os.listdir(VOCES_DIR) if f.endswith(".onnx"))
    if not modelos:
        return
    try:
        from piper import PiperVoice, SynthesisConfig
    except ImportError:
        print("Voz local desactivada: falta Piper (py -m pip install piper-tts). Uso la voz de Windows.")
        return
    try:
        piper["voz"] = PiperVoice.load(os.path.join(VOCES_DIR, modelos[0]))
        piper["cfg"] = SynthesisConfig
        piper["nombre"] = modelos[0][:-5]
        print(f"Voz local: {piper['nombre']}")
    except Exception as e:
        print(f"No pude cargar la voz {modelos[0]}: {e}. Uso la voz de Windows.")


def sintetizar(texto, velocidad):
    """Devuelve un WAV en bytes. velocidad < 1 = habla más rápido (length_scale)."""
    import io, wave
    buf = io.BytesIO()
    with piper["lock"], wave.open(buf, "wb") as wf:
        cfg = piper["cfg"](length_scale=velocidad)
        piper["voz"].synthesize_wav(texto, wf, syn_config=cfg)
    return buf.getvalue()


def modelos():
    try:
        return core.modelos_instalados()
    except Exception:
        return set()


def _ip_local(h):
    """True si h es una IP privada (192.168.x, 10.x, 172.16-31.x) o un nombre local, no internet."""
    if not h:
        return False
    if h in ("localhost",) or h.endswith(".local"):
        return True
    import ipaddress
    try:
        ip = ipaddress.ip_address(h)
        return ip.is_private or ip.is_loopback
    except ValueError:
        return True   # un nombre de equipo de la red (no una IP): se admite en modo red


class Manejador(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _permitido(self):
        """Bloquea peticiones de otras webs. En modo red acepta también la IP de este PC en la wifi."""
        host = self.headers.get("Host", "")
        propios = {f"localhost:{PUERTO}", f"127.0.0.1:{PUERTO}"}
        # el Host debe apuntar a este servidor (mismo puerto); en red vale cualquier IP local
        hostname = host.rsplit(":", 1)[0]
        puerto_ok = host.endswith(f":{PUERTO}") or (host and ":" not in host and PUERTO == 80)
        if not (host in propios or (EN_RED and puerto_ok and _ip_local(hostname))):
            return False
        origen = self.headers.get("Origin")
        if origen:
            o = urllib.parse.urlparse(origen)
            oh = o.hostname or ""
            if o.netloc not in propios and not (EN_RED and o.port == PUERTO and _ip_local(oh)):
                return False
        return True

    def handle_one_request(self):
        try:
            return super().handle_one_request()
        except (ConnectionResetError, BrokenPipeError):
            pass

    # ---------- utilidades ----------
    def _json(self, obj, code=200):
        datos = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(datos)))
        self.end_headers()
        self.wfile.write(datos)

    def _cuerpo(self):
        n = int(self.headers.get("Content-Length") or 0)
        try:
            return json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            return {}

    # ---------- rutas ----------
    def do_GET(self):
        if not self._permitido():
            self._json({"error": "origen no permitido"}, 403)
            return
        ruta = self.path.split("?")[0]
        if ruta in ("/", "/index.html"):
            with open(HTML, "rb") as f:
                datos = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(datos)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(datos)
        elif ruta == "/fondo-chat":
            for nombre, tipo in (("fondo-chat.jpg", "image/jpeg"), ("fondo-chat.png", "image/png"), ("fondo-chat.webp", "image/webp")):
                r = os.path.join(core.BASE, nombre)
                if os.path.isfile(r):
                    with open(r, "rb") as f:
                        datos = f.read()
                    self.send_response(200)
                    self.send_header("Content-Type", tipo)
                    self.send_header("Content-Length", str(len(datos)))
                    self.send_header("Cache-Control", "max-age=86400")
                    self.end_headers()
                    self.wfile.write(datos)
                    return
            self._json({"error": "sin fondo"}, 404)
        elif ruta in ("/avatar", "/intro"):
            prefijo = "intro" if ruta == "/intro" else "avatar"
            candidatos = [(prefijo + e, t) for e, t in ((".jpg","image/jpeg"),(".jpeg","image/jpeg"),(".png","image/png"),(".webp","image/webp"))]
            if ruta == "/intro":
                candidatos += [("avatar.jpg","image/jpeg"),("avatar.png","image/png")]   # si no hay intro, usa el avatar
            for nombre, tipo in candidatos:
                ruta = os.path.join(core.BASE, nombre)
                if os.path.isfile(ruta):
                    with open(ruta, "rb") as f:
                        datos = f.read()
                    self.send_response(200)
                    self.send_header("Content-Type", tipo)
                    self.send_header("Content-Length", str(len(datos)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(datos)
                    return
            self._json({"error": "sin avatar"}, 404)
        elif ruta == "/api/archivos":
            self._json({"archivos": listar_archivos()})
        elif ruta == "/api/archivo":
            rel = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("ruta", [""])[0]
            real = ruta_en_docs(rel)
            if not real:
                self._json({"error": "archivo no encontrado"}, 404)
                return
            ext = os.path.splitext(real)[1].lower()
            tipo = "text/plain; charset=utf-8" if ext in TIPOS_TEXTO else (mimetypes.guess_type(real)[0] or "application/octet-stream")
            with open(real, "rb") as f:
                datos = f.read()
            self.send_response(200)
            self.send_header("Content-Type", tipo)
            self.send_header("Content-Length", str(len(datos)))
            self.send_header("X-Content-Type-Options", "nosniff")   # un .html se ve como texto, nunca se ejecuta aquí
            self.end_headers()
            self.wfile.write(datos)
        elif ruta == "/api/chats":
            self._json({"chats": listar_chats()})
        elif ruta.startswith("/api/chats/"):
            c = leer_chat(ruta.rsplit("/", 1)[-1])
            self._json(c if c else {"error": "chat no encontrado"}, 200 if c else 404)
        elif ruta == "/api/estado":
            m = modelos()
            self._json({
                "ollama": bool(m),
                "rapido": core.MODELO_RAPIDO in m,
                "potente": core.MODELO_POTENTE in m,
                "fragmentos": len(estado["meta"]),
                "voz_local": piper["nombre"],
                "internet": web.disponible(),
                "internet_error": web.problema(),
                "claude": claude.clave_ok(),
                "claude_fin": claude.final_clave(),
                "claude_nombre": claude.NOMBRE,
                "vistas": f"http://{self.headers.get('Host','localhost').rsplit(':',1)[0]}:{PUERTO_VISTAS}",
                "pc": pc.ES_WINDOWS,
            })
        else:
            self._json({"error": "no encontrado"}, 404)

    def do_POST(self):
        if not self._permitido():
            self._json({"error": "origen no permitido"}, 403)
            return
        if self.path == "/api/vista":
            html = self._cuerpo().get("html", "")
            vid = os.urandom(8).hex()
            with bloqueo_vistas:
                VISTAS[vid] = html
                while len(VISTAS) > 50:                     # solo se guardan las últimas 50
                    VISTAS.pop(next(iter(VISTAS)))
            self._json({"url": f"http://localhost:{PUERTO_VISTAS}/vista/{vid}"})
            return
        if self.path == "/api/chat":
            self.chat()
        elif self.path == "/api/reindex":
            with bloqueo:
                vec, meta = core.indexar()
                estado["vec"], estado["meta"] = vec, meta
            self._json({"fragmentos": len(meta)})
        elif self.path == "/api/tts":
            d = self._cuerpo()
            texto = (d.get("texto") or "").strip()[:1000]
            if not piper["voz"] or not texto:
                self._json({"error": "voz local no disponible"}, 503)
                return
            try:
                velocidad = min(2.0, max(0.5, float(d.get("velocidad", 1.0))))
                wav = sintetizar(texto, velocidad)
            except Exception as e:
                self._json({"error": f"Piper falló: {e}"}, 500)
                return
            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(wav)))
            self.end_headers()
            self.wfile.write(wav)
        elif self.path == "/api/clave":
            try:
                claude.guardar_clave(self._cuerpo().get("clave", ""))
                self._json({"ok": True, "claude": claude.clave_ok(), "claude_fin": claude.final_clave()})
            except claude.ErrorClaude as e:
                self._json({"error": str(e)}, 400)
        elif self.path == "/api/pc":
            self.ejecutar_pc_confirmado()
        elif self.path == "/api/control":
            orden = self._cuerpo().get("orden", "")
            self._json(musica.control(orden) if orden in musica.TECLAS else {"ok": False, "mensaje": "Orden desconocida"})
        elif self.path.startswith("/api/chats/"):
            partes = self.path.split("/")          # /api/chats/<id>  o  /api/chats/<id>/borrar
            cid = partes[3] if len(partes) > 3 else ""
            if len(partes) > 4 and partes[4] == "borrar":
                r = ruta_chat(cid)
                if r and os.path.isfile(r):
                    os.remove(r)
                self._json({"ok": bool(r)})
            else:
                try:
                    c = guardar_chat(cid, self._cuerpo())
                    self._json({"ok": True, "id": c["id"], "titulo": c["titulo"]})
                except ValueError as e:
                    self._json({"error": str(e)}, 400)
        elif self.path == "/api/apagar":
            self._json({"ok": True})
            print("\nPineAI apagado desde la web.")
            threading.Thread(target=self.server.shutdown, daemon=True).start()
        elif self.path == "/api/obd":
            datos, err = core.leer_obd()
            self._json({"error": err} if err else {"datos": datos})
        else:
            self._json({"error": "no encontrado"}, 404)

    def ejecutar_pc_confirmado(self):
        d = self._cuerpo()
        self._json(ejecutar_pc(d.get("orden") or {}, d.get("musica_activa")))

    def chat(self):
        d = self._cuerpo()
        mensaje = (d.get("mensaje") or "").strip()
        if not mensaje:
            self._json({"error": "mensaje vacío"}, 400)
            return
        usar_claude = d.get("modelo") == "claude"
        modelo = core.MODELO_POTENTE if d.get("modelo") == "14b" else core.MODELO_RAPIDO
        historial = [h for h in d.get("historial", [])
                     if h.get("role") in ("user", "assistant") and isinstance(h.get("content"), str)]
        historial = historial[-core.MAX_HIST:]

        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()

        def enviar(obj):
            self.wfile.write((json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8"))
            self.wfile.flush()

        try:
            # 0a) ¿orden de control del PC? (abrir programas, volumen, apagar...) — sin IA
            # solo si el usuario ha activado el control del PC en Ajustes
            ordpc = pc.interpretar(mensaje, forzar=bool(d.get("abrir"))) if d.get("pc_activo") else None
            if not ordpc and d.get("abrir"):
                enviar({"aviso": "El control del PC está desactivado. Actívalo en Ajustes."})
            if ordpc and ordpc["accion"] in ("apagar", "reiniciar", "cerrar", "bloquear") and not d.get("confirmado"):
                q = {"apagar": "¿Apago el PC?", "reiniciar": "¿Reinicio el PC?",
                     "bloquear": "¿Bloqueo el PC?", "cerrar": f"¿Cierro {ordpc.get('objetivo','')}?"}[ordpc["accion"]]
                enviar({"confirmar_pc": q, "orden": ordpc}); enviar({"fin": True}); return
            if ordpc:
                res = ejecutar_pc(ordpc, d.get("musica_activa"))
                enviar({"pc": res}); enviar({"t": res["mensaje"]}); enviar({"fin": True}); return

            # 0b) ¿es una orden de música? Se atiende al momento, sin llamar a la IA
            orden = musica.interpretar(mensaje, forzar=bool(d.get("pon")))
            if orden:
                if orden["accion"] == "poner":
                    destino = orden["destino"] or d.get("destino_musica") or "youtube"
                    enviar({"buscando_musica": orden["consulta"]})
                    res = musica.poner(orden["consulta"], destino)
                elif d.get("reproductor_local"):
                    o = orden["orden"]   # el reproductor de PineAI lo controla la propia página
                    res = {"ok": True, "control": o, "mensaje": musica.TEXTOS_CONTROL[o]}
                    if o in ("siguiente", "anterior"):
                        res["mensaje"] = "En el reproductor de aquí solo hay un vídeo. Pídeme otra canción."
                else:
                    res = musica.control(orden["orden"])
                enviar({"musica": res})
                enviar({"t": res["mensaje"]})
                enviar({"fin": True})
                return

            partes = []
            adj = d.get("adjunto")
            if adj and adj.get("texto"):
                partes.append(f"Archivo adjunto '{adj.get('nombre', 'archivo')}':\n```\n"
                              f"{adj['texto'][:core.MAX_ARCHIVO]}\n```")

            # 1) tus documentos
            fragmentos = core.buscar(mensaje, estado["vec"], estado["meta"])
            enviar({"fuentes": sorted({m["archivo"] for m, _ in fragmentos})})
            if fragmentos:
                partes.append("Fragmentos relevantes de mis documentos:\n\n" +
                              "\n\n".join(f"[{m['archivo']}]\n{m['texto']}" for m, _ in fragmentos))

            # 2a) Claude: busca él mismo con su herramienta oficial, cuando lo ve necesario
            if usar_claude:
                forzada = (d.get("buscar") or "").strip()
                internet = d.get("internet") == "auto" or bool(forzada)
                contenido = ("\n\n".join(partes) + "\n\nPregunta: " + mensaje) if partes else mensaje
                if forzada:
                    contenido += f"\n\n(Busca en internet para responder: {forzada})"
                try:
                    uso = claude.chat(historial, contenido, internet, enviar)
                except claude.ErrorClaude as e:
                    enviar({"error": str(e)})
                    return
                enviar({"coste": uso})
                enviar({"fin": True})
                return

            # 2b) modelo local: forzado con /buscar, o si el modelo decide que hace falta
            consulta = (d.get("buscar") or "").strip()
            if not consulta and d.get("internet") == "auto" and web.disponible():
                enviar({"decidiendo": True})
                consulta = core.decidir_busqueda(modelo, mensaje, historial)
            if consulta:
                if not web.disponible():
                    enviar({"aviso": "Para buscar en internet falta instalar ddgs: ejecuta instalar.bat otra vez."})
                else:
                    enviar({"buscando": consulta})
                    try:
                        fuentes_web = web.buscar(consulta)
                    except Exception as e:
                        fuentes_web = []
                        enviar({"aviso": f"No pude buscar en internet: {e}"})
                    if fuentes_web:
                        enviar({"web": [{k: f[k] for k in ("titulo", "url", "dominio")} for f in fuentes_web]})
                        partes.append(web.como_contexto(fuentes_web))

            contenido = ("\n\n".join(partes) + "\n\nPregunta: " + mensaje) if partes else mensaje
            mensajes = historial + [{"role": "user", "content": contenido}]

            r, error = core.abrir_chat(modelo, mensajes, aviso=lambda t: enviar({"aviso": t}))
            if error:
                enviar({"error": error})
                return
            with r:
                for linea in r.iter_lines():
                    if not linea:
                        continue
                    parte = json.loads(linea)
                    trozo = parte.get("message", {}).get("content", "")
                    if trozo:
                        enviar({"t": trozo})
                    if parte.get("done"):
                        break
            enviar({"fin": True})
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass  # el usuario pulsó "Parar"
        except Exception as e:
            try:
                enviar({"error": f"No pude hablar con el modelo: {e}"})
            except Exception:
                pass


def ejecutar_pc(orden, musica_activa=False):
    a = orden.get("accion")
    try:
        if a == "abrir":
            return pc.abrir(orden.get("objetivo", ""))
        if a == "cerrar":
            return pc.cerrar(orden.get("objetivo", ""))
        if a in ("apagar", "reiniciar"):
            return pc.apagar(a == "reiniciar", orden.get("minutos", 0))
        # el volumen del sistema lo maneja la página si hay música sonando aquí
        if a in ("subir_vol", "bajar_vol", "silencio_vol") and musica_activa:
            return {"ok": True, "control_musica": a, "mensaje": "Ajusto el volumen de la música."}
        return pc.control(a, musica_activa)
    except Exception as e:
        return {"ok": False, "mensaje": f"No pude: {e}"}


def _mis_ips():
    import socket
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80)); ips.add(s.getsockname()[0]); s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127."):
                ips.add(ip)
    except Exception:
        pass
    return sorted(ips) or ["(no detectada)"]


def main():
    os.system("")
    if not core.arrancar_ollama() and claude.clave_ok():
        print(f"Ollama no está disponible: arranco solo con {claude.NOMBRE}.")
    else:
        core.comprobar_ollama()
    estado["vec"], estado["meta"] = core.cargar_indice()
    cargar_piper()
    if web.problema():
        print(f"Búsqueda en internet desactivada ({web.problema()}).")
        print("  Para activarla: py -m pip install ddgs beautifulsoup4")
    servidor = ThreadingHTTPServer((HOST, PUERTO), Manejador)
    vistas = ThreadingHTTPServer((HOST, PUERTO_VISTAS), ManejadorVistas)
    threading.Thread(target=vistas.serve_forever, daemon=True).start()
    url = f"http://localhost:{PUERTO}"
    print(f"\nPineAI Web en {url}  (cierra esta ventana para apagarlo)")
    print("Usa Chrome o Edge para el control por voz.")
    if EN_RED:
        print("\n*** MODO RED ACTIVADO ***")
        for ip in _mis_ips():
            print(f"  Desde otro PC del wifi, entra en:  http://{ip}:{PUERTO}")
        print("  Cualquiera en tu wifi puede entrar. No lo uses en redes públicas.")
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        pass
    servidor.server_close()


if __name__ == "__main__":
    main()
