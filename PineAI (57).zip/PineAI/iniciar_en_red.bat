@echo off
title PineAI (modo red)
cd /d "%~dp0"
net session >nul 2>&1
if %errorlevel%==0 (
  netsh advfirewall firewall delete rule name="PineAI" >nul 2>&1
  netsh advfirewall firewall add rule name="PineAI" dir=in action=allow protocol=TCP localport=8777-8778 >nul
  echo Cortafuegos abierto para PineAI.
) else (
  echo Para que otros PC entren, abre el cortafuegos una vez:
  echo   clic derecho en este .bat ^> Ejecutar como administrador
  echo Si solo quieres probar desde este PC, continua.
)
set PINEAI_RED=1
where py >nul 2>nul
if %errorlevel%==0 (py pineai_web.py) else (python pineai_web.py)
if errorlevel 1 pause
