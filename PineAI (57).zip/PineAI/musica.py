"""
PineAI - música y vídeos.
Entiende órdenes tipo «pon X en YouTube», «pausa», «siguiente», «sube el volumen»,
busca el vídeo y lo abre donde se le diga. Los controles usan las teclas multimedia de Windows.
"""
import json
import os
import re
import unicodedata
import urllib.parse
import webbrowser

import requests

YOUTUBE = os.environ.get("PINEAI_YOUTUBE_URL", "https://www.youtube.com").rstrip("/")
CABECERAS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/126.0 Safari/537.36",
    "Accept-Language": "es-ES,es;q=0.9",
}
# Evita la pantalla de consentimiento de cookies de YouTube en Europa
COOKIES = {"CONSENT": "YES+cb", "SOCS": "CAI"}

DESTINOS = {"youtube": "YouTube", "youtube_music": "YouTube Music", "spotify": "Spotify", "aqui": "PineAI"}


# ---------------- Entender la orden ----------------
def _normalizar(texto):
    t = unicodedata.normalize("NFD", texto.lower())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")          # quita tildes
    t = re.sub(r"[¿?¡!.,;:\"]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


RE_DESTINO = re.compile(r"\s+(?:en|por)\s+(?:el\s+|la\s+)?"
                        r"(youtube music|you tube music|youtube|you tube|yutub|spotify|espotify|"
                        r"aqui|pine ?ai|el chat|la pantalla)\s*$")
RE_PONER = re.compile(r"^(?:por favor\s+|oye\s+)?(?:(?:me |nos )?(?:puedes|podrias) (?:poner(?:me|nos)?|reproducir(?:me)?)|"
                      r"(?:me |nos )?pon(?:es|eis|me|nos)?|reproduce(?:me)?|toca(?:me)?|"
                      r"quiero (?:escuchar|oir|ver)|abre)\s+(?P<q>.+)$")
RE_AQUI = re.compile(r"\s+(?:aqui|aqui mismo|por aqui)\s*$")
RE_ESCUCHAR = re.compile(r"^quiero (?:escuchar|oir)\s")
RE_VERBO_MUSICAL = re.compile(r"^(?:por favor\s+|oye\s+)?(?:reproduce(?:me)?|toca(?:me)?|quiero (?:escuchar|oir))\s")
PALABRAS_MUSICA = re.compile(r"\b(cancion|canciones|musica|video|videos|tema|temas|disco|album|playlist|"
                             r"lista de reproduccion|radio|videoclip|directo|concierto|podcast)\b")
LIMPIAR_INICIO = re.compile(r"^(?:algo de |un poco de |la cancion (?:de )?|el video (?:de )?|el videoclip (?:de )?|"
                            r"el tema (?:de )?|la musica de |musica de )")
CONTROLES = [
    ("siguiente", re.compile(r"^(?:pon |pasa a |salta a )?(?:la )?(?:siguiente|proxima)(?: cancion| video| tema)?$|"
                             r"^(?:pasa|salta)(?: de)?(?: cancion| tema| video)?$|^otra cancion$|^next$")),
    ("anterior", re.compile(r"^(?:pon |vuelve a )?(?:la )?anterior(?: cancion| video| tema)?$|^vuelve atras$")),
    ("pausa", re.compile(r"^(?:pausa|pausala|para|parala|stop|deten(?:la)?|quita(?:la)?)"
                         r"(?: la musica| la cancion| el video| eso| esto)?$")),
    ("continuar", re.compile(r"^(?:continua|continuala|sigue|reanuda(?:la)?|play|dale al play|"
                             r"vuelve a ponerla|quita la pausa)(?: la musica| la cancion| el video)?$")),
    ("subir", re.compile(r"^(?:sube(?:le)?|mas alto|mas volumen|pon(?:lo|la)? mas alt[oa])(?: el volumen| la musica| el sonido)?(?: un poco)?$")),
    ("bajar", re.compile(r"^(?:baja(?:le)?|mas bajo|menos volumen|pon(?:lo|la)? mas baj[oa])(?: el volumen| la musica| el sonido)?(?: un poco)?$")),
    ("silencio", re.compile(r"^(?:silencia(?:la|lo)?|silencio|mute|quita el sonido)(?: la musica| el sonido)?$")),
]


def _destino(nombre):
    if "music" in nombre:
        return "youtube_music"
    if "spotify" in nombre:
        return "spotify"
    if "tu" in nombre or "yutub" in nombre:
        return "youtube"
    return "aqui"


def interpretar(texto, forzar=False):
    """
    Devuelve None si no es una orden de música, o:
      {"accion": "poner", "consulta": str, "destino": str|None}
      {"accion": "control", "orden": str}
    """
    t = _normalizar(texto)
    if not t:
        return None
    for orden, patron in CONTROLES:
        if patron.match(t):
            return {"accion": "control", "orden": orden}

    m = RE_PONER.match(t)
    if not m and not forzar:
        return None
    consulta, destino = (m.group("q") if m else t), None   # con /pon vale sin verbo
    d = RE_DESTINO.search(consulta)
    if d:
        destino = _destino(d.group(1))
        consulta = consulta[:d.start()].strip()
    elif RE_AQUI.search(consulta):
        destino = "aqui"
        consulta = RE_AQUI.sub("", consulta).strip()
    palabra_musica = bool(PALABRAS_MUSICA.search(consulta))
    verbo_musical = bool(RE_VERBO_MUSICAL.match(t))
    # YouTube/Spotify ya dicen que es música; «aquí» solo cuenta con palabra o verbo de música
    es_musica = (destino in ("youtube", "youtube_music", "spotify") or palabra_musica
                 or bool(RE_ESCUCHAR.match(t)) or (destino == "aqui" and verbo_musical))
    if not (es_musica or forzar) or not consulta:
        return None
    limpia = consulta
    while True:                                   # «algo de música de rock» -> «rock»
        nueva = LIMPIAR_INICIO.sub("", limpia).strip()
        if nueva == limpia or not nueva:
            break
        limpia = nueva
    consulta = limpia
    return {"accion": "poner", "consulta": consulta, "destino": destino}


# ---------------- Buscar en YouTube ----------------
# Tolerante a espacios, por si YouTube cambia el formato de sus datos internos
RE_VIDEO = re.compile(r'"videoRenderer"\s*:\s*\{\s*"videoId"\s*:\s*"([\w-]{11})".*?'
                      r'"title"\s*:\s*\{\s*"runs"\s*:\s*\[\s*\{\s*"text"\s*:\s*"((?:[^"\\]|\\.)*)"', re.S)


def buscar_youtube(consulta, cuantos=5):
    """Devuelve [{"id", "titulo"}] de los primeros vídeos, sin clave de API."""
    try:
        r = requests.get(f"{YOUTUBE}/results", params={"search_query": consulta},
                         headers=CABECERAS, cookies=COOKIES, timeout=10)
        videos, vistos = [], set()
        for vid, titulo in RE_VIDEO.findall(r.text):
            if vid in vistos:
                continue
            vistos.add(vid)
            try:
                titulo = json.loads(f'"{titulo}"')
            except json.JSONDecodeError:
                pass
            videos.append({"id": vid, "titulo": titulo})
            if len(videos) >= cuantos:
                break
        if videos:
            return videos
    except requests.RequestException:
        pass
    # Plan B: búsqueda de vídeos de DuckDuckGo (que tira de YouTube)
    try:
        from ddgs import DDGS
        videos = []
        for v in DDGS().videos(consulta, max_results=cuantos * 2):
            m = re.search(r"(?:v=|youtu\.be/)([\w-]{11})", v.get("content", "") or "")
            if m:
                videos.append({"id": m.group(1), "titulo": v.get("title", consulta)})
        return videos[:cuantos]
    except Exception:
        return []


def se_puede_incrustar(video_id):
    """Algunos vídeos (muchos videoclips oficiales) no dejan reproducirse dentro de otras páginas."""
    try:
        r = requests.get(f"{YOUTUBE}/oembed", params={"url": f"https://www.youtube.com/watch?v={video_id}",
                                                      "format": "json"}, headers=CABECERAS, timeout=6)
        return r.status_code == 200
    except requests.RequestException:
        return True  # si no se puede comprobar, se intenta igual


# ---------------- Abrir y controlar ----------------
def _abrir(url):
    if os.environ.get("PINEAI_SIMULAR_ABRIR"):          # para pruebas
        with open(os.environ["PINEAI_SIMULAR_ABRIR"], "a", encoding="utf-8") as f:
            f.write(url + "\n")
        return True
    if url.startswith("spotify:") and os.name == "nt":
        os.startfile(url)                                # abre la app de Spotify
        return True
    return webbrowser.open(url)


def poner(consulta, destino):
    """Busca y reproduce. Devuelve {"mensaje", ...} para responder al usuario."""
    destino = destino if destino in DESTINOS else "youtube"
    if destino == "spotify":
        try:
            _abrir("spotify:search:" + urllib.parse.quote(consulta, safe=""))
            return {"ok": True, "destino": destino,
                    "mensaje": f"Te abro Spotify con la búsqueda de «{consulta}». Dale al play en el primer resultado."}
        except OSError:
            _abrir("https://open.spotify.com/search/" + urllib.parse.quote(consulta, safe=""))
            return {"ok": True, "destino": destino,
                    "mensaje": f"No encuentro la app de Spotify, así que te abro Spotify web con «{consulta}»."}

    videos = buscar_youtube(consulta)
    if not videos:
        _abrir(f"https://www.youtube.com/results?search_query={urllib.parse.quote(consulta)}")
        return {"ok": False, "destino": "youtube",
                "mensaje": f"No he podido elegir un vídeo, te abro la búsqueda de «{consulta}» en YouTube."}

    if destino == "aqui":
        for v in videos:
            if se_puede_incrustar(v["id"]):
                return {"ok": True, "destino": "aqui", "id": v["id"], "titulo": v["titulo"],
                        "mensaje": f"Pongo «{v['titulo']}»."}
        v = videos[0]   # ninguno deja reproducirse dentro: se abre en YouTube
        _abrir(f"https://www.youtube.com/watch?v={v['id']}")
        return {"ok": True, "destino": "youtube", "id": v["id"], "titulo": v["titulo"],
                "mensaje": f"Ese vídeo no se puede poner aquí dentro, así que te pongo «{v['titulo']}» en YouTube."}

    v = videos[0]
    if destino == "youtube_music":
        _abrir(f"https://music.youtube.com/watch?v={v['id']}")
    else:
        _abrir(f"https://www.youtube.com/watch?v={v['id']}")
    return {"ok": True, "destino": destino, "id": v["id"], "titulo": v["titulo"],
            "mensaje": f"Pongo «{v['titulo']}» en {DESTINOS[destino]}."}


# Teclas multimedia de Windows (funcionan con YouTube en el navegador, Spotify, etc.)
TECLAS = {"pausa": 0xB3, "continuar": 0xB3, "siguiente": 0xB0, "anterior": 0xB1,
          "subir": 0xAF, "bajar": 0xAE, "silencio": 0xAD}
REPETICIONES = {"subir": 5, "bajar": 5}   # cada pulsación de volumen son 2 puntos
TEXTOS_CONTROL = {"pausa": "Pausado.", "continuar": "Seguimos.", "siguiente": "Siguiente.",
                  "anterior": "Anterior.", "subir": "Subo el volumen.", "bajar": "Bajo el volumen.",
                  "silencio": "Silencio."}


def control(orden):
    if os.environ.get("PINEAI_SIMULAR_ABRIR"):
        with open(os.environ["PINEAI_SIMULAR_ABRIR"], "a", encoding="utf-8") as f:
            f.write(f"tecla:{orden}\n")
        return {"ok": True, "mensaje": TEXTOS_CONTROL[orden]}
    if os.name != "nt":
        return {"ok": False, "mensaje": "Los controles de música solo funcionan en Windows."}
    import ctypes
    import time
    tecla = TECLAS[orden]
    for _ in range(REPETICIONES.get(orden, 1)):
        ctypes.windll.user32.keybd_event(tecla, 0, 0, 0)      # pulsar
        ctypes.windll.user32.keybd_event(tecla, 0, 2, 0)      # soltar
        time.sleep(0.02)
    return {"ok": True, "mensaje": TEXTOS_CONTROL[orden]}
