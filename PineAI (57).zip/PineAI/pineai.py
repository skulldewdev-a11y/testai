#!/usr/bin/env python3
"""
PineAI - asistente local de programación y electrónica automotriz.
Usa Ollama (modelo local) + RAG sobre la carpeta docs/ + lectura OBD2 opcional.
"""
import os
import sys
import json

import numpy as np
import requests

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

# ----------------------------- Configuración -----------------------------
OLLAMA = os.environ.get("PINEAI_OLLAMA", "http://localhost:11434").rstrip("/")
BASE = os.path.dirname(os.path.abspath(__file__))
DOCS_DIR = os.path.join(BASE, "docs")
INDEX_FILE = os.path.join(BASE, "indice.npy")
META_FILE = os.path.join(BASE, "indice.json")

MODELO_RAPIDO = "pineai"        # 7B, cabe entero en la GTX 1080
MODELO_POTENTE = "pineai-14b"   # modelo potente (gemma en Colab, o el 14B local)
EMBED = "nomic-embed-text"

EXTS = {".txt", ".md", ".pdf", ".py", ".js", ".ts", ".c", ".cpp", ".h", ".hpp",
        ".ino", ".lua", ".json", ".csv", ".ini", ".cfg", ".yaml", ".yml", ".xml",
        ".ps1", ".bat", ".sh", ".dbc", ".log"}
CHUNK = 1200          # caracteres por fragmento
SOLAPE = 200          # solape entre fragmentos
TOPK = 5              # fragmentos que se pasan al modelo
MIN_SIM = 0.40        # similitud mínima para considerar un fragmento relevante
MAX_HIST = 10         # mensajes de historial que se envían
MAX_ARCHIVO = 20000   # caracteres máximos al usar /leer

VERDE, CIAN, AMAR, GRIS, RESET = "\033[92m", "\033[96m", "\033[93m", "\033[90m", "\033[0m"

AYUDA = f"""{CIAN}Comandos:{RESET}
  /7b            usar el modelo rápido (por defecto)
  /14b           usar el modelo de 14B (más calidad, más lento)
  /leer RUTA     adjuntar un archivo a tu próxima pregunta
  /obd           leer datos en vivo y códigos de fallo por OBD2 y analizarlos
  /buscar TEXTO  buscar en internet y responder con lo encontrado
  /pon TEXTO     poner música o un vídeo («/pon lo-fi en spotify»)
  (también entiende «pon X en YouTube», «pausa», «siguiente», «sube el volumen»...)
  /reindex       volver a indexar la carpeta docs/
  /limpiar       borrar el historial de la conversación
  /ayuda         mostrar esta ayuda
  /salir         salir
Mete tus PDFs, notas y código en la carpeta docs/ y se usarán automáticamente."""


# ----------------------------- Ollama -----------------------------
def modelos_instalados():
    r = requests.get(f"{OLLAMA}/api/tags", timeout=5)
    r.raise_for_status()
    nombres = set()
    for m in r.json().get("models", []):
        n = m["name"]
        nombres.add(n)                 # nombre completo, p.ej. gemma4:26b
        nombres.add(n.split(":")[0])   # y el corto, p.ej. pineai
    return nombres


def arrancar_ollama():
    """Si Ollama no está corriendo, lo lanza en segundo plano y espera a que responda."""
    try:
        modelos_instalados()
        return True
    except Exception:
        pass
    import subprocess, shutil, time
    exe = shutil.which("ollama")
    if not exe and os.name == "nt":
        posible = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Ollama", "ollama.exe")
        exe = posible if os.path.isfile(posible) else None
    if not exe:
        return False
    print(f"{GRIS}Arrancando Ollama...{RESET}")
    flags = 0x08000000 | 0x00000008 if os.name == "nt" else 0  # sin ventana y desligado de esta consola
    subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     stdin=subprocess.DEVNULL, creationflags=flags)
    for _ in range(30):
        time.sleep(0.5)
        try:
            modelos_instalados()
            return True
        except Exception:
            pass
    return False


def comprobar_ollama():
    arrancar_ollama()
    try:
        instalados = modelos_instalados()
    except Exception:
        print(f"{AMAR}No encuentro Ollama en {OLLAMA}.{RESET}")
        print("Abre Ollama (o ejecuta 'ollama serve') y vuelve a lanzar PineAI.")
        sys.exit(1)
    if MODELO_RAPIDO not in instalados:
        print(f"{AMAR}Falta el modelo '{MODELO_RAPIDO}'. Ejecuta instalar.bat primero.{RESET}")
        sys.exit(1)
    return instalados


def embeber(textos):
    vecs = []
    for i in range(0, len(textos), 16):
        r = requests.post(f"{OLLAMA}/api/embed",
                          json={"model": EMBED, "input": textos[i:i + 16],
                                "options": {"num_gpu": 0}},  # en CPU: deja la VRAM al modelo de chat
                          timeout=300)
        r.raise_for_status()
        vecs.extend(r.json()["embeddings"])
        if len(textos) > 16:
            print(f"\r  {min(i + 16, len(textos))}/{len(textos)}", end="", flush=True)
    if len(textos) > 16:
        print()
    v = np.array(vecs, dtype=np.float32)
    n = np.linalg.norm(v, axis=1, keepdims=True)
    n[n == 0] = 1
    return v / n


def explicar_error(r, modelo):
    """Convierte un error HTTP de Ollama en un mensaje entendible."""
    try:
        detalle = r.json().get("error", "")
    except Exception:
        detalle = r.text.strip()[:300]
    d = detalle.lower()
    pista = ""
    if "not found" in d:
        pista = f" El modelo '{modelo}' no está instalado: ejecuta instalar.bat otra vez."
    elif es_oom(d) or "cuda" in d or "alloc" in d:
        pista = (" La gráfica no tiene VRAM libre ni con menos capas. Cierra juegos, fondos animados u otros "
                 "programas que usen la GPU (compruébalo con: nvidia-smi) o usa el modelo rápido (7B).")
    elif "terminated" in d or "exit status" in d or "runner" in d:
        pista = (" El motor de Ollama se ha cerrado al cargar el modelo. Mira el log en "
                 "%LOCALAPPDATA%\\Ollama\\server.log")
    return f"Ollama devolvió error {r.status_code}: {detalle or 'sin detalle'}.{pista}"


# Si la gráfica se queda sin VRAM, se reintenta con menos capas en la GPU (el resto va a la CPU)
REINTENTOS_GPU = [None, {"num_gpu": 22}, {"num_gpu": 14, "num_ctx": 4096}]


def es_oom(texto):
    t = texto.lower()
    return "out of memory" in t or "out-of-memory" in t or "oom" in t


_nivel_gpu = 0  # índice de REINTENTOS_GPU que funcionó la última vez (para no reintentar en cada mensaje)


def opciones_gpu():
    return dict(REINTENTOS_GPU[_nivel_gpu] or {})


def abrir_chat(modelo, mensajes, aviso=print):
    """Abre la respuesta en streaming de Ollama. Devuelve (respuesta, None) o (None, error)."""
    global _nivel_gpu
    error = None
    for n in range(_nivel_gpu, len(REINTENTOS_GPU)):
        opciones = REINTENTOS_GPU[n]
        cuerpo = {"model": modelo, "messages": mensajes, "stream": True}
        if opciones:
            cuerpo["options"] = opciones
        r = requests.post(f"{OLLAMA}/api/chat", json=cuerpo, stream=True, timeout=600)
        if r.status_code == 200:
            _nivel_gpu = n
            return r, None
        error = explicar_error(r, modelo)
        r.close()
        if not es_oom(error):
            return None, error
        if n + 1 < len(REINTENTOS_GPU):
            aviso("La gráfica no tiene VRAM suficiente; reintento con parte del modelo en la CPU (irá más lento)…")
    return None, error


ROUTER = (
    "Decides si para responder al usuario hace falta buscar en internet. Busca cuando pregunte por versiones, "
    "librerías, APIs o documentación concreta, proyectos o repositorios, errores o mensajes exactos, noticias, "
    "precios, productos, datos que cambian con el tiempo, o cuando pida expresamente que busques. No busques para "
    "saludos, charla, explicaciones generales, conceptos básicos ni código que puedas escribir sin consultar nada. "
    'Responde SOLO con JSON: {"buscar": true o false, "consulta": "texto para el buscador"}. '
    "La consulta debe ser corta (3 a 8 palabras); si es de programación, escríbela en inglés."
)


def decidir_busqueda(modelo, pregunta, historial=()):
    """Pregunta al modelo si hace falta buscar. Devuelve la consulta o None."""
    if len(pregunta.strip()) < 12:
        return None
    previo = "\n".join(f"{m['role']}: {m['content'][:300]}" for m in list(historial)[-4:])
    texto = (f"Conversación previa:\n{previo}\n\n" if previo else "") + f"Mensaje nuevo del usuario: {pregunta}"
    opciones = opciones_gpu()
    opciones.update({"num_predict": 80, "temperature": 0})
    try:
        r = requests.post(f"{OLLAMA}/api/chat", timeout=90, json={
            "model": modelo, "stream": False, "format": "json", "options": opciones,
            "messages": [{"role": "system", "content": ROUTER}, {"role": "user", "content": texto}]})
        if r.status_code != 200:
            return None
        d = json.loads(r.json()["message"]["content"])
        consulta = str(d.get("consulta", "")).strip()
        if d.get("buscar") is True and consulta:
            return consulta[:150]
    except Exception:
        pass
    return None


def responder(modelo, mensajes):
    salida = []
    try:
        r, error = abrir_chat(modelo, mensajes, aviso=lambda t: print(f"{GRIS}{t}{RESET}"))
        if error:
            print(f"{AMAR}{error}{RESET}")
            return ""
        print(f"{CIAN}pineai>{RESET} ", end="", flush=True)
        for linea in r.iter_lines():
            if not linea:
                continue
            d = json.loads(linea)
            trozo = d.get("message", {}).get("content", "")
            print(trozo, end="", flush=True)
            salida.append(trozo)
            if d.get("done"):
                break
    except KeyboardInterrupt:
        print(f"\n{GRIS}[respuesta cortada]{RESET}", end="")
    except Exception as e:
        print(f"\n{AMAR}Error hablando con el modelo: {e}{RESET}", end="")
    print()
    return "".join(salida)


# ----------------------------- Documentos (RAG) -----------------------------
def leer_archivo(ruta):
    ext = os.path.splitext(ruta)[1].lower()
    if ext == ".pdf":
        try:
            from pypdf import PdfReader
            return "\n".join((p.extract_text() or "") for p in PdfReader(ruta).pages)
        except ImportError:
            print(f"{AMAR}Para leer PDFs instala pypdf: pip install pypdf{RESET}")
        except Exception as e:
            print(f"{AMAR}No pude leer {ruta}: {e}{RESET}")
        return ""
    try:
        with open(ruta, encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        print(f"{AMAR}No pude leer {ruta}: {e}{RESET}")
        return ""


def trocear(texto):
    texto = texto.strip()
    trozos, i = [], 0
    while i < len(texto):
        trozos.append(texto[i:i + CHUNK])
        i += CHUNK - SOLAPE
    return trozos


def archivos_docs():
    for raiz, _, archivos in os.walk(DOCS_DIR):
        for a in archivos:
            if os.path.splitext(a)[1].lower() in EXTS:
                yield os.path.join(raiz, a)


def indexar():
    os.makedirs(DOCS_DIR, exist_ok=True)
    meta, textos = [], []
    for ruta in archivos_docs():
        rel = os.path.relpath(ruta, DOCS_DIR)
        for t in trocear(leer_archivo(ruta)):
            meta.append({"archivo": rel, "texto": t})
            textos.append("search_document: " + t)
    if not textos:
        print(f"{GRIS}La carpeta docs/ está vacía: respondo solo con lo que sabe el modelo.{RESET}")
        for f in (INDEX_FILE, META_FILE):
            if os.path.exists(f):
                os.remove(f)
        return None, []
    print(f"{GRIS}Indexando {len(textos)} fragmentos de tus documentos...{RESET}")
    try:
        vec = embeber(textos)
    except Exception as e:
        print(f"{AMAR}No pude indexar (¿falta '{EMBED}'?): {e}{RESET}")
        return None, []
    np.save(INDEX_FILE, vec)
    with open(META_FILE, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False)
    print(f"{GRIS}Índice listo.{RESET}")
    return vec, meta


def cargar_indice():
    os.makedirs(DOCS_DIR, exist_ok=True)
    if os.path.exists(INDEX_FILE) and os.path.exists(META_FILE):
        t_indice = os.path.getmtime(INDEX_FILE)
        cambios = any(os.path.getmtime(r) > t_indice for r in archivos_docs())
        if not cambios:
            with open(META_FILE, encoding="utf-8") as f:
                vec, meta = np.load(INDEX_FILE), json.load(f)
            # ¿El índice se hizo con el mismo modelo de embeddings? Si cambió, las dimensiones no encajan
            try:
                if vec.ndim == 2 and embeber(["prueba"]).shape[1] == vec.shape[1]:
                    return vec, meta
                print(f"{GRIS}El índice es de otro modelo de embeddings: lo rehago.{RESET}")
            except Exception:
                return vec, meta   # sin Ollama no se puede comprobar; se usa tal cual
        print(f"{GRIS}Hay documentos nuevos o modificados.{RESET}")
    return indexar()


def buscar(pregunta, vec, meta):
    if vec is None or not meta:
        return []
    try:
        q = embeber(["search_query: " + pregunta])[0]
    except Exception:
        return []
    if vec.ndim != 2 or q.shape[0] != vec.shape[1]:
        # índice de otro modelo: se ignora para no romper la respuesta (se rehace con /reindex o al reiniciar)
        print(f"{AMAR}El índice de tus documentos no encaja con el modelo actual. Usa /reindex.{RESET}")
        return []
    sims = vec @ q
    mejores = np.argsort(-sims)[:TOPK]
    return [(meta[i], float(sims[i])) for i in mejores if sims[i] >= MIN_SIM]


# ----------------------------- OBD2 -----------------------------
PIDS = ["RPM", "SPEED", "COOLANT_TEMP", "INTAKE_TEMP", "ENGINE_LOAD", "THROTTLE_POS",
        "MAF", "INTAKE_PRESSURE", "FUEL_PRESSURE", "TIMING_ADVANCE",
        "SHORT_FUEL_TRIM_1", "LONG_FUEL_TRIM_1", "O2_B1S1", "CONTROL_MODULE_VOLTAGE"]


def leer_obd():
    try:
        import obd
    except ImportError:
        return None, "Falta la librería OBD: pip install obd"
    print(f"{GRIS}Conectando al adaptador OBD2...{RESET}")
    conn = obd.OBD()  # detecta el puerto automáticamente
    if not conn.is_connected():
        return None, "No se pudo conectar. Revisa el adaptador, el puerto COM y el contacto puesto."
    datos = {}
    for nombre in PIDS:
        cmd = getattr(obd.commands, nombre, None)
        if cmd is not None and conn.supports(cmd):
            r = conn.query(cmd)
            if not r.is_null():
                datos[nombre] = str(r.value)
    r = conn.query(obd.commands.GET_DTC)
    dtcs = [f"{c} {d}".strip() for c, d in (r.value or [])] if not r.is_null() else []
    conn.close()
    return {"lecturas": datos, "codigos_fallo": dtcs}, None


# ----------------------------- Música -----------------------------
def atender_musica(texto, forzar=False):
    """Si el texto es una orden de música, la ejecuta y devuelve True."""
    try:
        import musica
    except ImportError:
        return False
    orden = musica.interpretar(texto, forzar=forzar)
    if not orden:
        return False
    if orden["accion"] == "poner":
        destino = orden["destino"] if orden["destino"] in ("youtube", "youtube_music", "spotify") else "youtube"
        print(f"{GRIS}Buscando «{orden['consulta']}»...{RESET}")
        res = musica.poner(orden["consulta"], destino)
    else:
        res = musica.control(orden["orden"])
    print(f"{CIAN}pineai>{RESET} {res['mensaje']}")
    return True


# ----------------------------- Bucle principal -----------------------------
def main():
    os.system("")  # activa colores ANSI en la consola de Windows
    instalados = comprobar_ollama()
    vec, meta = cargar_indice()
    modelo = MODELO_RAPIDO
    historial = []
    adjunto = None

    print(f"\n{CIAN}=== PineAI ==={RESET}  modelo: {modelo}  |  docs: {len(meta)} fragmentos")
    print(f"{GRIS}Escribe /ayuda para ver los comandos.{RESET}")

    while True:
        try:
            entrada = input(f"\n{VERDE}tú>{RESET} ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not entrada:
            continue

        if entrada.startswith("/"):
            cmd, _, arg = entrada.partition(" ")
            cmd, arg = cmd.lower(), arg.strip().strip('"')
            if cmd in ("/salir", "/exit"):
                break
            if cmd == "/ayuda":
                print(AYUDA)
            elif cmd == "/7b":
                modelo = MODELO_RAPIDO
                print(f"{GRIS}Usando {modelo}.{RESET}")
            elif cmd == "/14b":
                if MODELO_POTENTE in instalados:
                    modelo = MODELO_POTENTE
                    print(f"{GRIS}Usando {modelo} (irá más lento).{RESET}")
                else:
                    print(f"{AMAR}No tienes instalado {MODELO_POTENTE}. Vuelve a ejecutar instalar.bat y di que sí al 14B.{RESET}")
            elif cmd == "/reindex":
                vec, meta = indexar()
            elif cmd == "/limpiar":
                historial, adjunto = [], None
                print(f"{GRIS}Historial borrado.{RESET}")
            elif cmd == "/leer":
                if not arg or not os.path.isfile(arg):
                    print(f"{AMAR}Uso: /leer C:\\ruta\\al\\archivo{RESET}")
                else:
                    contenido = leer_archivo(arg)[:MAX_ARCHIVO]
                    adjunto = f"Archivo adjunto '{os.path.basename(arg)}':\n```\n{contenido}\n```"
                    print(f"{GRIS}Adjuntado ({len(contenido)} caracteres). Haz tu pregunta.{RESET}")
            elif cmd == "/pon":
                if not arg:
                    print(f"{AMAR}Uso: /pon lo que quieras escuchar [en youtube / youtube music / spotify]{RESET}")
                else:
                    atender_musica(arg, forzar=True)
            elif cmd == "/buscar":
                if not arg:
                    print(f"{AMAR}Uso: /buscar lo que quieras buscar{RESET}")
                else:
                    try:
                        import web
                        print(f"{GRIS}Buscando en internet: {arg}...{RESET}")
                        fuentes = web.buscar(arg)
                    except Exception as e:
                        print(f"{AMAR}No pude buscar en internet: {e}{RESET}")
                        fuentes = []
                    if fuentes:
                        for i, f in enumerate(fuentes, 1):
                            print(f"{GRIS}  [{i}] {f['titulo']} - {f['url']}{RESET}")
                        adjunto = web.como_contexto(fuentes)
                        entrada = arg
            elif cmd == "/obd":
                datos, err = leer_obd()
                if err:
                    print(f"{AMAR}{err}{RESET}")
                else:
                    print(f"{GRIS}{json.dumps(datos, ensure_ascii=False, indent=2)}{RESET}")
                    entrada = ("Analiza estas lecturas OBD2 en vivo de mi coche. Dime qué valores "
                               "están fuera de lo normal y qué significan los códigos de fallo:\n"
                               + json.dumps(datos, ensure_ascii=False, indent=2))
            else:
                print(f"{AMAR}Comando desconocido. Escribe /ayuda.{RESET}")
            if not ((cmd == "/obd" and entrada.startswith("Analiza")) or (cmd == "/buscar" and adjunto and entrada == arg)):
                continue

        if atender_musica(entrada):
            continue

        partes = []
        if adjunto:
            partes.append(adjunto)
            adjunto = None
        fragmentos = buscar(entrada, vec, meta)
        if fragmentos:
            fuentes = sorted({m["archivo"] for m, _ in fragmentos})
            print(f"{GRIS}Usando: {', '.join(fuentes)}{RESET}")
            partes.append("Fragmentos relevantes de mis documentos:\n\n" +
                          "\n\n".join(f"[{m['archivo']}]\n{m['texto']}" for m, _ in fragmentos))
        contenido = ("\n\n".join(partes) + "\n\nPregunta: " + entrada) if partes else entrada

        mensajes = historial[-MAX_HIST:] + [{"role": "user", "content": contenido}]
        respuesta = responder(modelo, mensajes)
        if respuesta:
            historial += [{"role": "user", "content": entrada},
                          {"role": "assistant", "content": respuesta}]


if __name__ == "__main__":
    main()
