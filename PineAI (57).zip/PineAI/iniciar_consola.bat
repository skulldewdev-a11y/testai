@echo off
title PineAI (consola)
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py pineai.py) else (python pineai.py)
pause
