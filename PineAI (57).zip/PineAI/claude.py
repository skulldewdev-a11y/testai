"""
PineAI - motor en la nube: Claude Opus 5.5 por la API de Anthropic.
Streaming, búsqueda web oficial de Claude (con citas) y cálculo del coste de cada respuesta.
"""
import json
import os
import re

import requests

BASE = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(BASE, "config.json")
API = os.environ.get("PINEAI_ANTHROPIC_URL", "https://api.anthropic.com").rstrip("/")
MODELO = "claude-opus-5-5"
NOMBRE = "Claude Opus 5.5"

# Precios en dólares (septiembre 2026): 4 $/M entrada, 20 $/M salida, 10 $ por 1.000 búsquedas
PRECIO_ENTRADA = 4 / 1_000_000
PRECIO_SALIDA = 20 / 1_000_000
PRECIO_BUSQUEDA = 0.01

MAX_TOKENS = 4000
MAX_BUSQUEDAS = 5
# Primero la herramienta de búsqueda nueva; si la API no la acepta, se usa la básica
VERSIONES_BUSQUEDA = ["web_search_20260209", "web_search_20250305"]
_version = 0

SISTEMA = """Eres PineAI, un asistente técnico experto en dos áreas:
1. Programación: Python, C/C++, Arduino/ESP32, JavaScript, Lua, scripts de Windows y Linux. Escribes código completo, funcional y comentado.
2. Electrónica automotriz: diagnóstico OBD2/EOBD, códigos de fallo, CAN bus, K-Line, centralitas (ECU/DME), sensores, actuadores, esquemas eléctricos, swaps de motor e integración de electrónica.

Reglas:
- Responde siempre en español, de forma directa y práctica, en tono cercano.
- Tus respuestas se leen en voz alta: usa frases claras y evita tablas y formato recargado salvo que ayuden de verdad. El código va en bloques de código.
- Si te paso fragmentos de mis documentos o archivos, básate en ellos primero y di de qué archivo sale la información.
- Si no estás seguro de un dato concreto (un pinout, un valor de sensor, un ID de CAN), dilo y explica cómo comprobarlo.
- Avisa de riesgos reales: airbag, alta tensión, combustible, cortocircuitos que pueden dañar una centralita.
- Si tienes búsqueda web, úsala cuando haga falta información actual o específica (versiones, documentación, proyectos, errores concretos, precios) y no la uses para lo que ya sabes."""


class ErrorClaude(Exception):
    pass


# ---------------- Clave de API ----------------
def _leer_config():
    try:
        with open(CONFIG, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def leer_clave():
    return os.environ.get("ANTHROPIC_API_KEY") or _leer_config().get("anthropic_api_key", "")


def clave_ok():
    return bool(leer_clave())


def final_clave():
    k = leer_clave()
    return k[-4:] if k else ""


def guardar_clave(clave):
    """Comprueba la clave contra la API (listar modelos no cuesta nada) y la guarda en config.json."""
    clave = clave.strip()
    cfg = _leer_config()
    if not clave:
        cfg.pop("anthropic_api_key", None)
    else:
        if not clave.startswith("sk-ant-"):
            raise ErrorClaude("Eso no parece una clave de Anthropic: empiezan por sk-ant-")
        try:
            r = requests.get(f"{API}/v1/models", headers=_cabeceras(clave), timeout=15)
            if r.status_code in (401, 403):
                raise ErrorClaude("La API rechaza esa clave. Revisa que la hayas copiado entera.")
        except requests.RequestException:
            pass  # sin conexión: se guarda igualmente y se verá al usarla
        cfg["anthropic_api_key"] = clave
    with open(CONFIG, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


def _cabeceras(clave=None):
    return {"x-api-key": clave or leer_clave(), "anthropic-version": "2023-06-01",
            "content-type": "application/json"}


def _explicar(codigo, mensaje):
    pistas = {
        401: "La clave de API no es válida. Cámbiala en Ajustes.",
        403: "Tu clave no tiene permiso para este modelo o esta función.",
        429: "Has llegado al límite de uso de la API. Espera un poco o revisa tus límites en la consola de Anthropic.",
        529: "Los servidores de Anthropic están saturados ahora mismo. Prueba en unos segundos.",
    }
    if "credit" in mensaje.lower() or "billing" in mensaje.lower():
        return "No te queda saldo en la cuenta de la API de Anthropic. Recarga créditos en la consola."
    return f"{pistas.get(codigo, 'Error de la API de Claude.')} ({codigo}: {mensaje})"


def _dominio(url):
    return re.sub(r"^https?://(www\.)?", "", url).split("/")[0]


# ---------------- Conversación ----------------
def chat(historial, contenido, internet, enviar):
    """
    Pregunta a Claude en streaming. enviar(obj) recibe los eventos para la interfaz:
      {"t": texto}  {"buscando": consulta}  {"web": [fuentes]}  {"aviso": ...}
    Devuelve un dict con el uso y el coste.
    """
    global _version
    if not clave_ok():
        raise ErrorClaude("Falta la clave de API de Claude. Ponla en Ajustes.")
    mensajes = list(historial) + [{"role": "user", "content": contenido}]
    uso = {"entrada": 0, "salida": 0, "busquedas": 0}
    fuentes = []

    vueltas = 0
    while vueltas < 4:
        vueltas += 1
        cuerpo = {"model": MODELO, "max_tokens": MAX_TOKENS, "system": SISTEMA,
                  "messages": mensajes, "stream": True}
        if internet:
            cuerpo["tools"] = [{"type": VERSIONES_BUSQUEDA[_version], "name": "web_search",
                                "max_uses": MAX_BUSQUEDAS}]
        try:
            r = requests.post(f"{API}/v1/messages", headers=_cabeceras(), json=cuerpo,
                              stream=True, timeout=300)
        except requests.RequestException as e:
            raise ErrorClaude(f"No hay conexión con la API de Claude: {e}")
        if r.status_code != 200:
            try:
                msg = r.json().get("error", {}).get("message", r.text)
            except Exception:
                msg = r.text[:300]
            r.close()
            # la herramienta de búsqueda nueva no está disponible: se reintenta con la básica
            if internet and r.status_code == 400 and _version + 1 < len(VERSIONES_BUSQUEDA) and "web_search" in msg:
                _version += 1
                vueltas -= 1
                continue
            raise ErrorClaude(_explicar(r.status_code, msg))

        with r:
            bloques, motivo = _leer_stream(r, enviar, fuentes, uso)
        if motivo == "pause_turn":
            # búsqueda larga: la API pide continuar el mismo turno
            mensajes = mensajes + [{"role": "assistant", "content": bloques}]
            continue
        if motivo == "max_tokens":
            enviar({"aviso": "La respuesta se cortó por larga. Pídeme que continúe."})
        break

    uso["coste"] = round(uso["entrada"] * PRECIO_ENTRADA + uso["salida"] * PRECIO_SALIDA
                         + uso["busquedas"] * PRECIO_BUSQUEDA, 5)
    return uso


def _leer_stream(r, enviar, fuentes, uso):
    bloques, actual, json_parcial, citas = [], None, "", []
    motivo, entrada_llamada = None, 0

    def numero_fuente(url, titulo=""):
        for i, f in enumerate(fuentes, 1):
            if f["url"] == url:
                return i
        fuentes.append({"titulo": titulo or _dominio(url), "url": url, "dominio": _dominio(url)})
        enviar({"web": fuentes})
        return len(fuentes)

    for linea in r.iter_lines(decode_unicode=True):
        if not linea or not linea.startswith("data:"):
            continue
        ev = json.loads(linea[5:].strip())
        tipo = ev.get("type")

        if tipo == "message_start":
            u = ev.get("message", {}).get("usage", {})
            entrada_llamada = (u.get("input_tokens", 0) + u.get("cache_creation_input_tokens", 0)
                               + u.get("cache_read_input_tokens", 0))

        elif tipo == "content_block_start":
            actual, json_parcial, citas = dict(ev["content_block"]), "", []
            if actual.get("type") == "web_search_tool_result":
                resultados = actual.get("content")
                if isinstance(resultados, list):
                    antes = len(fuentes)
                    for x in resultados:
                        if x.get("type") == "web_search_result" and x.get("url"):
                            if not any(f["url"] == x["url"] for f in fuentes):
                                fuentes.append({"titulo": x.get("title") or _dominio(x["url"]),
                                                "url": x["url"], "dominio": _dominio(x["url"])})
                    if len(fuentes) > antes:
                        enviar({"web": fuentes})
                elif isinstance(resultados, dict) and resultados.get("error_code"):
                    enviar({"aviso": f"La búsqueda falló ({resultados['error_code']})."})

        elif tipo == "content_block_delta":
            d = ev.get("delta", {})
            if d.get("type") == "text_delta":
                actual["text"] = actual.get("text", "") + d["text"]
                enviar({"t": d["text"]})
            elif d.get("type") == "input_json_delta":
                json_parcial += d.get("partial_json", "")
            elif d.get("type") == "citations_delta":
                c = d.get("citation", {})
                actual["citations"] = (actual.get("citations") or []) + [c]
                if c.get("url"):
                    citas.append(numero_fuente(c["url"], c.get("title", "")))

        elif tipo == "content_block_stop":
            if actual is None:
                continue
            if actual.get("type") == "server_tool_use":
                try:
                    actual["input"] = json.loads(json_parcial) if json_parcial else actual.get("input", {})
                except json.JSONDecodeError:
                    actual["input"] = {}
                consulta = actual["input"].get("query") if isinstance(actual["input"], dict) else None
                if consulta:
                    enviar({"buscando": consulta})
            if actual.get("type") == "text":
                if citas:
                    enviar({"t": "".join(f"[{n}]" for n in sorted(set(citas)))})
                if not actual.get("citations"):
                    actual.pop("citations", None)   # la API no acepta citations: null al reenviar
            bloques.append(actual)
            actual = None

        elif tipo == "message_delta":
            motivo = ev.get("delta", {}).get("stop_reason") or motivo
            u = ev.get("usage", {})
            uso["salida"] += u.get("output_tokens", 0)
            entrada_llamada = max(entrada_llamada, u.get("input_tokens", 0) + u.get("cache_read_input_tokens", 0)
                                  + u.get("cache_creation_input_tokens", 0))
            uso["busquedas"] += (u.get("server_tool_use") or {}).get("web_search_requests", 0)

        elif tipo == "error":
            raise ErrorClaude(_explicar(0, ev.get("error", {}).get("message", "error desconocido")))

    uso["entrada"] += entrada_llamada
    return bloques, motivo
