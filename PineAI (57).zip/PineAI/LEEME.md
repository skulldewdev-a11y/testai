# PineAI

Asistente local de programación y electrónica automotriz. Funciona 100 % en tu PC (GTX 1080 + 16 GB RAM) con Ollama.

## Instalación
1. Ten instalado Python 3.10+ (marca "Add to PATH" al instalarlo).
2. Doble clic en `instalar.bat`. Instala Ollama, descarga los modelos y las librerías.
3. Mete tus documentos en `docs/` (PDFs de esquemas, pinouts, manuales, notas .md/.txt, código, archivos .dbc...). Puedes usar subcarpetas.
4. Doble clic en `iniciar.bat`: arranca Ollama si hace falta y abre el chat en el navegador.

## Interfaz con voz y avatar
Doble clic en `iniciar.bat`. Se abre `http://localhost:8777` en el navegador (usa **Chrome o Edge**).

- **Micro** (o `Ctrl+Espacio`): hablas y al callarte se envía solo. La primera vez el navegador te pedirá permiso para el micrófono.
- **Leer las respuestas en voz alta**: el avatar habla y la boca (barra de luces) se mueve con la voz. El código no lo lee, lo deja en pantalla.
- **«Ey Pine»**: activa en Ajustes *Activar con «Ey Pine»* y el micro se queda atento. Di «Ey Pine» y espera el pitido para preguntar, o dilo todo seguido: «Ey Pine, ¿qué hace la N75?». Mientras piensa o habla deja de escuchar, para no activarse con su propia voz. Ojo: mientras está activado, el audio del micro lo procesa el reconocimiento de voz de Chrome/Edge en sus servidores.
- **Manos libres**: cuando termina de hablar vuelve a escucharte solo, para usarlo sin tocar nada (por ejemplo en el taller).
- **Efecto de voz**: *Anonymous* (grave, robótica y metálica), *Grave* o *Normal*. Al cambiarlo suena una frase de prueba. La voz se genera en tu PC con Piper (carpeta `voces/`, la instala `instalar.bat`) y los efectos se aplican en el navegador. Si Piper no está, usa la voz de Windows: solo puede ponerla grave, sin el efecto robótico.
- Para cambiar la voz base, pon otro modelo de Piper (`.onnx` + `.onnx.json`) en `voces/` y deja solo ese.
- **Avatar**: es `avatar.jpg`. Al hablar se le mueve la mascarilla como si abriera la boca y le brillan los ojos (más fuerte cuando te escucha). Si la cambias por otra imagen (o por la original a más resolución), abre `http://localhost:8777/?ajuste=1`: verás marcados los ojos y la zona de la boca, y los ajustas en `CARA` al principio del script de `interfaz.html`.
- **Internet**: si en Ajustes está activado *Buscar en internet cuando haga falta*, antes de responder el modelo decide si tu pregunta necesita información de internet (versiones, librerías, documentación, proyectos, errores concretos...). Si hace falta, busca en varios buscadores a la vez (Google, Bing, DuckDuckGo, Brave, Wikipedia...), lee las mejores páginas y responde citando las fuentes con [1], [2]..., que son enlaces. Con `/buscar lo que sea` fuerzas una búsqueda. Ojo: lo que se busca sí sale a internet.
- **Música y vídeos**: dile «pon Despacito en YouTube», «¿me pones música de rock en Spotify?», «reproduce lo-fi aquí» o usa `/pon`. Si no dices dónde, usa lo elegido en Ajustes > *Poner la música en*. Destinos: YouTube y YouTube Music (se abre el vídeo ya sonando), Spotify (se abre la app con la búsqueda hecha; el play lo das tú) y *Aquí* (mini reproductor dentro de PineAI, que baja el volumen mientras ella te escucha o habla). Controles: «pausa», «sigue», «siguiente», «anterior», «sube/baja el volumen», «silencio», o los cuadraditos `/pausa` y `/siguiente`. Para YouTube en el navegador y Spotify usan las teclas multimedia de Windows. Estas órdenes no pasan por la IA: son instantáneas y no gastan nada con Claude.
- **Chats guardados**: las conversaciones se guardan solas en la carpeta `chats/` (un archivo por chat, con sus fuentes y costes). Pulsa la pestañita del borde izquierdo del chat para ver la lista: pulsa uno para abrirlo, el lápiz para renombrarlo o la papelera para borrarlo. *+ Nuevo chat* o `/limpiar` empiezan uno limpio sin perder el anterior. Al abrir PineAI vuelve el último chat. Si pasas PineAI a alguien, borra antes la carpeta `chats/`.
- **Visor de archivos** (a la derecha): cada bloque de código del chat tiene un botón *Abrir*; las páginas HTML que te haga se abren solas en vista previa. La pestañita del borde derecho del chat abre la lista con los bloques de código del chat y los archivos de `docs/` (texto, código, Markdown, PDF, imágenes). Arriba: vista previa / código, copiar, descargar, ampliar y cerrar. Las páginas se sirven desde un segundo servidor en el puerto siguiente (8778): funcionan con todo (guardar datos, cargar sus archivos de al lado, conectarse al bridge) pero no pueden tocar PineAI. Con el botón de *abrir en el navegador* las ves a pantalla completa en su propia pestaña. Si una página usa imágenes o scripts propios, copia su carpeta entera dentro de `docs/`. El visor solo puede leer archivos de la carpeta `docs/`.
- **Seguridad**: PineAI solo acepta órdenes de su propia página, así que ninguna otra web que visites puede apagarlo, leer tus chats ni cambiarte la clave.
- **Controlar el PC** (solo Windows): actívalo primero en Ajustes > IA > *Dejar que controle el PC* (viene apagado). Una vez activado: dile «abre VS Code / la calculadora / descargas», «abre Assetto Corsa» (busca en el menú Inicio), «cierra Chrome», «sube/baja el volumen», «silencia», «sube/baja el brillo», «bloquea el PC», «apaga en 30 minutos», «cancela el apagado». O el comando `/abre`. Estas órdenes son instantáneas y no gastan IA. Apagar, reiniciar, bloquear y cerrar programas piden confirmación antes de hacerse. Si hay música sonando en el reproductor de aquí, «sube el volumen» la sube a ella; si no, al sistema. Detecta los programas solos, así que «abre X» funciona con lo que tengas instalado.
- **Fondo del chat**: la imagen `fondo-chat.jpg` se ve tenue detrás de la conversación. Para quitarla, Ajustes > Música > *Imagen de fondo en el chat*. Para cambiarla, sustituye ese archivo por otro con el mismo nombre.
- **Comandos**: menú con los mismos comandos que la consola (`/7b`, `/14b`, `/claude`, `/leer`, `/buscar`, `/obd`, `/pon`, `/abre`, `/pausa`, `/siguiente`, `/reindex`, `/limpiar`, `/ayuda`, `/salir`) en cuadraditos. También puedes escribirlos en el chat. `/salir` apaga PineAI y cierra la ventana negra.
- Botones para leer el coche por OBD, reindexar documentos y adjuntar archivos de código.

Ojo: el modelo y tus documentos se quedan en tu PC, pero el dictado por voz de Chrome/Edge envía el audio a los servidores de Google/Microsoft para pasarlo a texto y necesita internet. La voz que lee las respuestas sí es local.

## Claude Opus 5.5 (opcional, en la nube y de pago)
PineAI puede usar Claude Opus 5.5 en vez del modelo local: mucho más listo, pero funciona en los servidores de Anthropic y se paga por uso (4 $ por millón de tokens de entrada, 20 $ por millón de salida y 1 céntimo por búsqueda web; una pregunta normal sale por 1 o 2 céntimos de dólar, con búsqueda web entre 5 y 10).

1. Crea una cuenta en platform.claude.com, añade saldo y crea una clave de API. Es independiente de la suscripción Pro/Max de claude.ai.
2. En PineAI: Ajustes > *Clave de API de Claude* > pégala y dale a *Guardar*. Se comprueba al momento.
3. Pulsa `/claude` (o elige Claude en *Modelo*). Para volver al local: `/7b`.

Con Claude, las búsquedas en internet las hace el propio Claude con su buscador oficial. Bajo cada respuesta ves lo que ha costado y arriba el total del día. Si Ollama no está abierto y tienes clave, PineAI arranca directamente con Claude.

**Ojo:** la clave se guarda en `config.json`, dentro de la carpeta de PineAI. No compartas ese archivo; si pasas PineAI a alguien, bórralo antes.

## Uso en consola
Si prefieres el chat en la ventana negra, sin voz ni avatar: `iniciar_consola.bat`.

Pregunta normal y PineAI busca en tus documentos antes de responder (te dice de qué archivos ha sacado la info).

| Comando | Qué hace |
|---|---|
| `/14b` / `/7b` | Cambiar entre modelo potente y rápido |
| `/leer RUTA` | Adjuntar un archivo de código a la siguiente pregunta |
| `/obd` | Leer datos en vivo y DTCs por OBD2 (adaptador ELM327 USB/Bluetooth) y analizarlos |
| `/reindex` | Reindexar `docs/` (también se hace solo al arrancar si hay cambios) |
| `/limpiar` | Borrar historial |

## Personalizar
- La personalidad y reglas están en `Modelfile`. Si la cambias, ejecuta: `ollama create pineai -f Modelfile`
- Para probar otro modelo base, cambia la línea `FROM` del Modelfile y recréalo.
- Ajustes de búsqueda (tamaño de fragmentos, cuántos se usan) al principio de `pineai.py`.

## Notas
- `/obd` solo lee PIDs estándar; cada centralita soporta unos u otros, los que no responda se omiten.
- Los PDFs escaneados (imágenes) no tienen texto extraíble; pásalos antes por un OCR.

## Usar PineAI desde otro PC del mismo wifi
1. En el PC donde está PineAI, **clic derecho en `iniciar_en_red.bat` > Ejecutar como administrador** (la primera vez, para abrir el cortafuegos). Las siguientes veces ya puedes abrirlo con doble clic normal.
2. Al arrancar te muestra una dirección tipo `http://192.168.1.XX:8777`. Esa es la IP de tu PC en el wifi.
3. En el otro ordenador (conectado al **mismo wifi**), abre Chrome o Edge y escribe esa dirección.

Avisos:
- Mientras está en modo red, **cualquiera conectado a tu wifi puede entrar** a PineAI (usar la IA, ver tus chats y, si lo activaste, controlar tu PC). Úsalo solo en tu wifi de confianza, nunca en una pública.
- PineAI solo acepta conexiones de tu red local; las webs de internet no pueden entrar.
- Para volver al modo privado (solo tu PC), arranca con `iniciar.bat` de siempre.
