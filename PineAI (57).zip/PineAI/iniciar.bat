@echo off
title PineAI
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py pineai_web.py) else (python pineai_web.py)
if errorlevel 1 pause
