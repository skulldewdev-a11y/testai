"""
PineAI - control del PC (Windows).
Nivel 1: acciones concretas y seguras. Entiende órdenes por texto, sin llamar a la IA.
Abrir programas y carpetas, cerrar programas, volumen y brillo del sistema, bloquear, apagar/reiniciar.
"""
import os
import re
import subprocess
import unicodedata

ES_WINDOWS = os.name == "nt"

# Carpetas conocidas por su nombre hablado -> variable/carpeta real
CARPETAS = {
    "descargas": "Downloads", "documentos": "Documents", "escritorio": "Desktop",
    "imagenes": "Pictures", "fotos": "Pictures", "musica": "Music", "videos": "Videos",
    "video": "Videos", "descarga": "Downloads",
}
# Programas por su nombre hablado -> lo que se ejecuta. Primero se busca en el menú Inicio (cubre casi todo).
ALIAS_PROGRAMAS = {
    "vs code": "code", "visual studio code": "code", "code": "code", "visual code": "code",
    "bloc de notas": "notepad", "notas": "notepad", "notepad": "notepad",
    "calculadora": "calc", "calc": "calc",
    "paint": "mspaint", "explorador": "explorer", "explorador de archivos": "explorer",
    "cmd": "cmd", "consola": "cmd", "terminal": "wt", "powershell": "powershell",
    "navegador": "", "chrome": "chrome", "edge": "msedge", "firefox": "firefox",
    "spotify": "spotify", "discord": "discord", "steam": "steam",
    "administrador de tareas": "taskmgr", "panel de control": "control",
    "configuracion": "ms-settings:", "ajustes": "ms-settings:",
}


def _norm(texto):
    t = unicodedata.normalize("NFD", texto.lower())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    t = re.sub(r"[¿?¡!.,;:\"]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


# --- órdenes ---
RE_CARPETA_DE = re.compile(r"^(?:la |el )?carpeta (?:de |del )?")
RE_ABRIR = re.compile(r"^(?:por favor\s+|oye\s+)?(?:abre(?:me)?|ejecuta(?:me)?|arranca(?:me)?|lanza(?:me)?|inicia(?:me)?|"
                      r"pon(?:me)? en marcha|entra en|ve a)\s+(?P<q>.+)$")
RE_CERRAR = re.compile(r"^(?:cierra(?:me)?|mata(?:me)?|termina(?:me)?)\s+(?P<q>.+)$")
CONTROLES = [
    ("subir_vol", re.compile(r"^(?:sube(?:le)?|mas alto|mas volumen)(?: el volumen| el sonido)?(?: del (?:pc|ordenador|sistema))?(?: un poco)?$")),
    ("bajar_vol", re.compile(r"^(?:baja(?:le)?|mas bajo|menos volumen)(?: el volumen| el sonido)?(?: del (?:pc|ordenador|sistema))?(?: un poco)?$")),
    ("silencio_vol", re.compile(r"^(?:silencia(?:lo)?|silencio|quita el sonido|mute)(?: el (?:pc|ordenador|sistema))?$")),
    ("subir_brillo", re.compile(r"^(?:sube(?:le)?|mas)(?: el)? brillo(?: un poco)?$|^mas brillo$")),
    ("bajar_brillo", re.compile(r"^(?:baja(?:le)?|menos)(?: el)? brillo(?: un poco)?$|^menos brillo$")),
    ("bloquear", re.compile(r"^bloquea(?:me)?(?: el (?:pc|ordenador|equipo))?$|^bloquear$")),
    ("cancelar_apagado", re.compile(r"^(?:cancela|anula|para|no apagues)(?: el)?(?: apagado| reinicio)?$")),
]
RE_APAGAR = re.compile(r"^(?:apaga(?:me)?|apagar)(?: el)?(?: pc| ordenador| equipo| sistema)?(?:\s+en\s+(?P<min>\d+)\s*(?:min|minutos?|m))?\s*$")
RE_REINICIAR = re.compile(r"^(?:reinicia(?:me)?|reiniciar|reset)(?: el)?(?: pc| ordenador| equipo)?(?:\s+en\s+(?P<min>\d+)\s*(?:min|minutos?|m))?\s*$")

# Cosas que NO son abrir programas aunque empiecen por "abre/entra": evita disparar acciones por error
NO_ES_ABRIR = re.compile(r"\b(archivo|fichero|documento|carpeta de|el chat|la conversacion|un tema|la pagina|"
                         r"la puerta|los ojos|la boca|paso|pasos|ejemplo|codigo|script|funcion|el capo|"
                         r"el maletero|la valvula|el turbo|una cuenta|sesion|mente|posibilidad)\b")


def interpretar(texto, forzar=False):
    t = _norm(texto)
    if not t:
        return None
    for accion, patron in CONTROLES:
        if patron.match(t):
            return {"accion": accion}
    m = RE_APAGAR.match(t)
    if m:
        return {"accion": "apagar", "minutos": int(m.group("min") or 0)}
    m = RE_REINICIAR.match(t)
    if m:
        return {"accion": "reiniciar", "minutos": int(m.group("min") or 0)}
    m = RE_CERRAR.match(t)
    if m:
        return {"accion": "cerrar", "objetivo": m.group("q").strip()}
    m = RE_ABRIR.match(t)
    bruto = m.group("q").strip() if m else (t if forzar else None)
    if bruto is not None:
        objetivo = RE_CARPETA_DE.sub("", bruto) or bruto
        if not forzar and objetivo not in CARPETAS and NO_ES_ABRIR.search(bruto):
            return None
        return {"accion": "abrir", "objetivo": objetivo}
    return None


# --- ejecución ---
def _carpeta(nombre):
    sub = CARPETAS.get(nombre)
    if not sub:
        return None
    ruta = os.path.join(os.path.expanduser("~"), sub)
    return ruta if os.path.isdir(ruta) else os.path.expanduser("~")


def _buscar_en_inicio(nombre):
    """Busca un acceso directo .lnk en el menú Inicio cuyo nombre contenga lo pedido."""
    dirs = [os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"), r"Microsoft\Windows\Start Menu\Programs"),
            os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs")]
    palabras = nombre.split()
    mejor = None
    for base in dirs:
        for raiz, _, archivos in os.walk(base):
            for a in archivos:
                if not a.lower().endswith((".lnk", ".url")):
                    continue
                slug = _norm(os.path.splitext(a)[0])
                if all(p in slug for p in palabras):
                    ruta = os.path.join(raiz, a)
                    # el nombre más corto suele ser el programa principal, no un "desinstalar" ni un extra
                    if mejor is None or len(slug) < mejor[0]:
                        mejor = (len(slug), ruta)
    return mejor[1] if mejor else None


def _existe_comando(cmd):
    if cmd.endswith(":"):     # ms-settings: y similares
        return True
    from shutil import which
    return bool(which(cmd) or which(cmd + ".exe"))


def puede_abrir(objetivo):
    """¿Sabríamos abrir esto? Devuelve una pista de qué es, o None."""
    n = _norm(objetivo)
    if n.startswith("la ") or n.startswith("el "):
        n = n[3:]
    if n in CARPETAS:
        return ("carpeta", n)
    alias = ALIAS_PROGRAMAS.get(n)
    if alias and _existe_comando(alias):
        return ("alias", alias)
    if _buscar_en_inicio(n):
        return ("inicio", n)
    if alias == "":       # "navegador" sin uno por defecto claro
        return ("web", n)
    return None


def _lanzar(cmd, shell=False):
    if os.environ.get("PINEAI_SIMULAR_PC"):
        with open(os.environ["PINEAI_SIMULAR_PC"], "a", encoding="utf-8") as f:
            f.write((cmd if isinstance(cmd, str) else " ".join(cmd)) + "\n")
        return
    if not ES_WINDOWS:
        raise OSError("solo en Windows")
    if isinstance(cmd, str) and (cmd.endswith(":") or cmd.startswith("http")):
        os.startfile(cmd)
    else:
        subprocess.Popen(cmd, shell=shell)


def abrir(objetivo):
    n = _norm(objetivo)
    if n.startswith(("la ", "el ")):
        n = n[3:]
    if n in CARPETAS:
        _lanzar(["explorer", _carpeta(n)])
        return {"ok": True, "mensaje": f"Abro la carpeta {n}."}
    alias = ALIAS_PROGRAMAS.get(n)
    if alias and _existe_comando(alias):
        _lanzar([alias] if not alias.endswith(":") else alias, shell=False)
        return {"ok": True, "mensaje": f"Abro {objetivo}."}
    lnk = _buscar_en_inicio(n)
    if lnk:
        _lanzar(["cmd", "/c", "start", "", lnk])
        return {"ok": True, "mensaje": f"Abro {objetivo}."}
    return {"ok": False, "mensaje": f"No encuentro «{objetivo}» en el PC."}


def cerrar(objetivo):
    n = _norm(objetivo)
    exe = ALIAS_PROGRAMAS.get(n) or n.replace(" ", "")
    if not exe or exe.endswith(":"):
        return {"ok": False, "mensaje": f"No sé qué programa es «{objetivo}»."}
    if not exe.lower().endswith(".exe"):
        exe += ".exe"
    _lanzar(["taskkill", "/IM", exe, "/F"])
    return {"ok": True, "mensaje": f"Cierro {objetivo}."}


def _tecla_volumen(codigo, veces):
    if os.environ.get("PINEAI_SIMULAR_PC"):
        with open(os.environ["PINEAI_SIMULAR_PC"], "a", encoding="utf-8") as f:
            f.write(f"tecla_vol:{codigo}x{veces}\n")
        return
    import ctypes
    import time
    for _ in range(veces):
        ctypes.windll.user32.keybd_event(codigo, 0, 0, 0)
        ctypes.windll.user32.keybd_event(codigo, 0, 2, 0)
        time.sleep(0.02)


def _brillo(subir):
    # WMI: ajusta el brillo en pasos de 20 (solo portátiles/monitores compatibles)
    ps = ("$m=Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightness;"
          "$n=Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods;"
          "$b=$m.CurrentBrightness;"
          f"$b=[Math]::Max(0,[Math]::Min(100,$b{'+' if subir else '-'}20));"
          "$n.WmiSetBrightness(1,$b)")
    _lanzar(["powershell", "-NoProfile", "-Command", ps])


def control(accion, musica_activa=False):
    if accion in ("subir_vol", "bajar_vol", "silencio_vol"):
        codigo = {"subir_vol": 0xAF, "bajar_vol": 0xAE, "silencio_vol": 0xAD}[accion]
        _tecla_volumen(codigo, 1 if accion == "silencio_vol" else 5)
        que = {"subir_vol": "Subo el volumen.", "bajar_vol": "Bajo el volumen.", "silencio_vol": "Silencio."}[accion]
        return {"ok": True, "mensaje": que}
    if accion in ("subir_brillo", "bajar_brillo"):
        _brillo(accion == "subir_brillo")
        return {"ok": True, "mensaje": "Subo el brillo." if accion == "subir_brillo" else "Bajo el brillo."}
    if accion == "bloquear":
        _lanzar(["rundll32.exe", "user32.dll,LockWorkStation"])
        return {"ok": True, "mensaje": "Bloqueo el PC."}
    if accion == "cancelar_apagado":
        _lanzar(["shutdown", "/a"])
        return {"ok": True, "mensaje": "Cancelo el apagado."}
    return {"ok": False, "mensaje": "No sé hacer eso."}


def apagar(reiniciar, minutos):
    seg = max(0, int(minutos)) * 60
    _lanzar(["shutdown", "/r" if reiniciar else "/s", "/t", str(seg)])
    verbo = "Reinicio" if reiniciar else "Apago"
    cuando = f" en {minutos} minutos" if minutos else " ahora"
    return {"ok": True, "mensaje": f"{verbo} el PC{cuando}. Di «cancela el apagado» si te arrepientes."}
